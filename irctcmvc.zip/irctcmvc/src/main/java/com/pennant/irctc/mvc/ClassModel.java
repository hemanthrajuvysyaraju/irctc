package com.pennant.irctc.mvc;

public class ClassModel {
	private Integer index;
	private String Class_Name;
	protected Integer getIndex() {
		return index;
	}
	protected void setIndex(Integer index) {
		this.index = index;
	}
	protected String getClass_Name() {
		return Class_Name;
	}
	protected void setClass_Name(String class_Name) {
		Class_Name = class_Name;
	}
	
}
