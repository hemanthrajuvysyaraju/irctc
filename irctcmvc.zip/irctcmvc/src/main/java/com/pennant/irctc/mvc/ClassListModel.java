package com.pennant.irctc.mvc;

import java.util.ArrayList;

public class ClassListModel extends ArrayList<ClassModel> {
	private static final long serialVersionUID = -7728015511910375238L;

}
