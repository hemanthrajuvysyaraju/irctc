package com.pennant.irctc.mvc;

import java.util.ArrayList;

public class StationListModel extends ArrayList<StationModel> {

	private static final long serialVersionUID = 1L;

}
